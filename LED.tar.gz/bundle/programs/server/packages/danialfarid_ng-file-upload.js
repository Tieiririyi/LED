(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

(function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// packages/danialfarid_ng-file-upload/packages/danialfarid_ng-file- //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
                                                                     // 1
///////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['danialfarid:ng-file-upload'] = {};

})();

//# sourceMappingURL=danialfarid_ng-file-upload.js.map
