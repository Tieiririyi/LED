(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mys:angular-storage'] = {};

})();

//# sourceMappingURL=mys_angular-storage.js.map
