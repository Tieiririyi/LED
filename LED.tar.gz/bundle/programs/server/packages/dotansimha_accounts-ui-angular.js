(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['dotansimha:accounts-ui-angular'] = {};

})();

//# sourceMappingURL=dotansimha_accounts-ui-angular.js.map
