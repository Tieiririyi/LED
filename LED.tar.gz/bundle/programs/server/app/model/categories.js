(function(){/**
 * Created by Tieiririyi on 2016-02-07.
 */
Categories = new Mongo.Collection("categories");

Categories.allow({
    insert: function insert(userId, doc) {
        return Roles.userIsInRole(userId, ['admin', 'super-admin'], 'led');
    },
    update: function update(userId, doc, fields, modifier) {
        return Roles.userIsInRole(userId, ['admin', 'super-admin'], 'led');
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9tb2RlbC9jYXRlZ29yaWVzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUdBLFVBQVUsR0FBRyxJQUFJLEtBQUssQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7O0FBRWhELFVBQVUsQ0FBQyxLQUFLLENBQUM7QUFDYixVQUFNLEVBQUUsZ0JBQVMsTUFBTSxFQUFFLEdBQUcsRUFBQztBQUN6QixlQUFPLEtBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQ3RFO0FBQ0QsVUFBTSxFQUFFLGdCQUFTLE1BQU0sRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBQztBQUMzQyxlQUFPLEtBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO0tBQ3RFO0NBQ0osQ0FBQyxDQUFDIiwiZmlsZSI6Ii9tb2RlbC9jYXRlZ29yaWVzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBDcmVhdGVkIGJ5IFRpZWlyaXJpeWkgb24gMjAxNi0wMi0wNy5cbiAqL1xuQ2F0ZWdvcmllcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKFwiY2F0ZWdvcmllc1wiKTtcblxuQ2F0ZWdvcmllcy5hbGxvdyh7XG4gICAgaW5zZXJ0OiBmdW5jdGlvbih1c2VySWQsIGRvYyl7XG4gICAgICAgIHJldHVybiBSb2xlcy51c2VySXNJblJvbGUodXNlcklkLCBbJ2FkbWluJywgJ3N1cGVyLWFkbWluJ10sICdsZWQnKTtcbiAgICB9LFxuICAgIHVwZGF0ZTogZnVuY3Rpb24odXNlcklkLCBkb2MsIGZpZWxkcywgbW9kaWZpZXIpe1xuICAgICAgICByZXR1cm4gUm9sZXMudXNlcklzSW5Sb2xlKHVzZXJJZCwgWydhZG1pbicsICdzdXBlci1hZG1pbiddLCAnbGVkJyk7XG4gICAgfVxufSk7Il19
}).call(this);

//# sourceMappingURL=categories.js.map
