(function(){
Meteor.publish("orders", function () {
    return Orders.find();
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9zZXJ2ZXIvb3JkZXJzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFDQSxNQUFNLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxZQUFZO0FBQ2pDLFdBQU8sTUFBTSxDQUFDLElBQUksRUFBRSxDQUFDO0NBQ3hCLENBQUMsQ0FBQyIsImZpbGUiOiIvc2VydmVyL29yZGVycy5qcyIsInNvdXJjZXNDb250ZW50IjpbIlxuTWV0ZW9yLnB1Ymxpc2goXCJvcmRlcnNcIiwgZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiBPcmRlcnMuZmluZCgpO1xufSk7Il19
}).call(this);

//# sourceMappingURL=orders.js.map
