(function(){/**
 * Created by Tieiririyi on 2016-01-24.
 */
//Meteor.startup(function () {

Meteor.startup(function () {

    //Categories.remove({});
    if (Categories.find().count() === 0) {

        var categories = [{
            'categoryName': 'LED bulbs',
            'categoryDescription': 'Amazing LED light bulbs.',
            'picture': ''
        }, {
            'categoryName': 'Fixtures',
            'categoryDescription': 'Premium Design.',
            'picture': ''
        }, {
            'categoryName': 'Signs',
            'categoryDescription': 'Customized LED Signs.',
            'picture': ''
        }];

        for (var i = 0; i < categories.length; i++) {
            Categories.insert(categories[i]);
        }
    }

    // Images.find().forEach(function(images){
    //  Images.remove({_id: images._id});
    //  });

    //Orders.remove({});
    //Products.remove({});
    if (Products.find().count() === 0) {
        var id = Categories.findOne({ "categoryName": "LED bulbs" })._id;
        for (var i = 1; i <= 50; i++) {
            var itemNum = "DPAR38-16WT(S" + i + ")";
            Products.insert({
                "itemNum": itemNum,
                "size": "122*135mm",
                "socket": "E26",
                "power": 16,
                "brightness": 1250,
                "temperature": 3000,
                "Ra": ">=80",
                "voltage": "100-130",
                "beam_angle": 120,
                "life_time": 50000,
                "power_factor": ">=0.9",
                "dimmable": "yes",
                "housing": "aluminum",
                "colour": "silver",
                "cover": "glass lens",
                "certification": ["CE", "ETL"],
                "categoryId": id,
                "picture": "",
                "price": 10.99,
                "quantityInStock": 100,
                "quantityOnHold": 10,
                "discount_pct": 10,
                "status": true
            });
        }
        // Products.insert(
        //     {
        //         "itemNum": "DPAR38-16WT(S2)",
        //         "size": "122*135mm",
        //         "socket": "E26",
        //         "power": 16,
        //         "brightness": 1250,
        //         "temperature": 3000,
        //         "Ra": ">=80",
        //         "voltage": "100-130",
        //         "beam_angle": 120,
        //         "life_time": 50000,
        //         "power_factor": ">=0.9",
        //         "dimmable": "yes",
        //         "housing": "aluminum",
        //         "colour": "silver",
        //         "cover": "glass lens",
        //         "certification": ["CE", "ETL"],
        //         "categoryId": id,
        //         "picture": "",
        //         "price": 10.99,
        //         "quantityInStock": 100,
        //         "quantityOnHold": 10,
        //         "discount_pct": 0.1
        //     },
        // );
        // Products.insert(
        //     {
        //         "itemNum": "DPAR38-16WT(S2)",
        //         "size": "122*135mm",
        //         "socket": "E27",
        //         "power": 16,
        //         "brightness": 1250,
        //         "temperature": 3000,
        //         "Ra": ">=80",
        //         "voltage": "100-130",
        //         "beam_angle": 120,
        //         "life_time": 50000,
        //         "power_factor": ">=0.9",
        //         "dimmable": "yes",
        //         "housing": "aluminum",
        //         "colour": "silver",
        //         "cover": "glass lens",
        //         "certification": ["CE", "ETL"],
        //         "categoryId": id,
        //         "picture": "",
        //         "price": 10.99,
        //         "quantityInStock": 100,
        //         "quantityOnHold": 10,
        //         "discount_pct": 0
        //     }
        // );
    }

    if (Meteor.roles.findOne({ name: "super-admin" }) == undefined) {
        Accounts.createUser({
            email: "super.admin@led.com",
            password: "12345678",
            profile: {
                name: "super-admin",
                status: "active"
            }
        });
        //        Roles.setUserRoles(targetUserId, roles, group);

        Roles.setUserRoles(Meteor.users.findOne({ "profile.name": "super-admin" })._id, ["super-admin"], 'led');
    }
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9zZXJ2ZXIvc3RhcnR1cC9sb2FkQ2F0ZWdvcmllcy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7OztBQU1JLE1BQU0sQ0FBQyxPQUFPLENBQUMsWUFBWTs7O0FBSXZCLFFBQUksVUFBVSxDQUFDLElBQUksRUFBRSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUMsRUFBRTs7QUFFakMsWUFBSSxVQUFVLEdBQUcsQ0FDYjtBQUNJLDBCQUFjLEVBQUUsV0FBVztBQUMzQixpQ0FBcUIsRUFBRSwwQkFBMEI7QUFDakQscUJBQVMsRUFBQyxFQUFFO1NBQ2YsRUFDRDtBQUNJLDBCQUFjLEVBQUUsVUFBVTtBQUMxQixpQ0FBcUIsRUFBRSxpQkFBaUI7QUFDeEMscUJBQVMsRUFBQyxFQUFFO1NBQ2YsRUFDRDtBQUNJLDBCQUFjLEVBQUUsT0FBTztBQUN2QixpQ0FBcUIsRUFBRSx1QkFBdUI7QUFDOUMscUJBQVMsRUFBQyxFQUFFO1NBQ2YsQ0FDSixDQUFDOztBQUVGLGFBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ3hDLHNCQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3BDO0tBQ0o7Ozs7Ozs7O0FBUUQsUUFBSSxRQUFRLENBQUMsSUFBSSxFQUFFLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQyxFQUFFO0FBQy9CLFlBQUksRUFBRSxHQUFHLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBQyxjQUFjLEVBQUUsV0FBVyxFQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7QUFDL0QsYUFBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxJQUFFLEVBQUUsRUFBQyxDQUFDLEVBQUUsRUFBQztBQUN0QixnQkFBSSxPQUFPLEdBQUcsZUFBZSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUE7QUFDdkMsb0JBQVEsQ0FBQyxNQUFNLENBQ1g7QUFDSSx5QkFBUyxFQUFFLE9BQU87QUFDbEIsc0JBQU0sRUFBRSxXQUFXO0FBQ25CLHdCQUFRLEVBQUUsS0FBSztBQUNmLHVCQUFPLEVBQUUsRUFBRTtBQUNYLDRCQUFZLEVBQUUsSUFBSTtBQUNsQiw2QkFBYSxFQUFFLElBQUk7QUFDbkIsb0JBQUksRUFBRSxNQUFNO0FBQ1oseUJBQVMsRUFBRSxTQUFTO0FBQ3BCLDRCQUFZLEVBQUUsR0FBRztBQUNqQiwyQkFBVyxFQUFFLEtBQUs7QUFDbEIsOEJBQWMsRUFBRSxPQUFPO0FBQ3ZCLDBCQUFVLEVBQUUsS0FBSztBQUNqQix5QkFBUyxFQUFFLFVBQVU7QUFDckIsd0JBQVEsRUFBRSxRQUFRO0FBQ2xCLHVCQUFPLEVBQUUsWUFBWTtBQUNyQiwrQkFBZSxFQUFFLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQztBQUM5Qiw0QkFBWSxFQUFFLEVBQUU7QUFDaEIseUJBQVMsRUFBRSxFQUFFO0FBQ2IsdUJBQU8sRUFBRSxLQUFLO0FBQ2QsaUNBQWlCLEVBQUUsR0FBRztBQUN0QixnQ0FBZ0IsRUFBRSxFQUFFO0FBQ3BCLDhCQUFjLEVBQUUsRUFBRTtBQUNsQix3QkFBUSxFQUFFLElBQUk7YUFDakIsQ0FDSixDQUFDO1NBQ0w7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0tBcURKOztBQUVELFFBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsRUFBQyxJQUFJLEVBQUUsYUFBYSxFQUFDLENBQUMsSUFBSSxTQUFTLEVBQUM7QUFDekQsZ0JBQVEsQ0FBQyxVQUFVLENBQUM7QUFDaEIsaUJBQUssRUFBRSxxQkFBcUI7QUFDNUIsb0JBQVEsRUFBRSxVQUFVO0FBQ3BCLG1CQUFPLEVBQUU7QUFDTCxvQkFBSSxFQUFFLGFBQWE7QUFDbkIsc0JBQU0sRUFBRSxRQUFRO2FBQ25CO1NBQ0osQ0FBQyxDQUFDOzs7QUFHSCxhQUFLLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEVBQUMsY0FBYyxFQUFFLGFBQWEsRUFBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsYUFBYSxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7S0FDekc7Q0FFSixDQUFDLENBQUMiLCJmaWxlIjoiL3NlcnZlci9zdGFydHVwL2xvYWRDYXRlZ29yaWVzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBDcmVhdGVkIGJ5IFRpZWlyaXJpeWkgb24gMjAxNi0wMS0yNC5cbiAqL1xuLy9NZXRlb3Iuc3RhcnR1cChmdW5jdGlvbiAoKSB7XG5cblxuICAgIE1ldGVvci5zdGFydHVwKGZ1bmN0aW9uICgpIHtcblxuXG4gICAgICAgIC8vQ2F0ZWdvcmllcy5yZW1vdmUoe30pO1xuICAgICAgICBpZiAoQ2F0ZWdvcmllcy5maW5kKCkuY291bnQoKSA9PT0gMCkge1xuXG4gICAgICAgICAgICB2YXIgY2F0ZWdvcmllcyA9IFtcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICdjYXRlZ29yeU5hbWUnOiAnTEVEIGJ1bGJzJyxcbiAgICAgICAgICAgICAgICAgICAgJ2NhdGVnb3J5RGVzY3JpcHRpb24nOiAnQW1hemluZyBMRUQgbGlnaHQgYnVsYnMuJyxcbiAgICAgICAgICAgICAgICAgICAgJ3BpY3R1cmUnOicnXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICdjYXRlZ29yeU5hbWUnOiAnRml4dHVyZXMnLFxuICAgICAgICAgICAgICAgICAgICAnY2F0ZWdvcnlEZXNjcmlwdGlvbic6ICdQcmVtaXVtIERlc2lnbi4nLFxuICAgICAgICAgICAgICAgICAgICAncGljdHVyZSc6JydcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgJ2NhdGVnb3J5TmFtZSc6ICdTaWducycsXG4gICAgICAgICAgICAgICAgICAgICdjYXRlZ29yeURlc2NyaXB0aW9uJzogJ0N1c3RvbWl6ZWQgTEVEIFNpZ25zLicsXG4gICAgICAgICAgICAgICAgICAgICdwaWN0dXJlJzonJ1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIF07XG5cbiAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgY2F0ZWdvcmllcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIENhdGVnb3JpZXMuaW5zZXJ0KGNhdGVnb3JpZXNbaV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gSW1hZ2VzLmZpbmQoKS5mb3JFYWNoKGZ1bmN0aW9uKGltYWdlcyl7XG4gICAgICAgIC8vICBJbWFnZXMucmVtb3ZlKHtfaWQ6IGltYWdlcy5faWR9KTtcbiAgICAgICAgLy8gIH0pO1xuXG4gICAgICAgIC8vT3JkZXJzLnJlbW92ZSh7fSk7XG4gICAgICAgIC8vUHJvZHVjdHMucmVtb3ZlKHt9KTtcbiAgICAgICAgaWYgKFByb2R1Y3RzLmZpbmQoKS5jb3VudCgpID09PSAwKSB7XG4gICAgICAgICAgICB2YXIgaWQgPSBDYXRlZ29yaWVzLmZpbmRPbmUoe1wiY2F0ZWdvcnlOYW1lXCI6IFwiTEVEIGJ1bGJzXCJ9KS5faWQ7XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMTsgaTw9NTA7aSsrKXtcbiAgICAgICAgICAgICAgICB2YXIgaXRlbU51bSA9IFwiRFBBUjM4LTE2V1QoU1wiICsgaSArIFwiKVwiXG4gICAgICAgICAgICAgICAgUHJvZHVjdHMuaW5zZXJ0KFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBcIml0ZW1OdW1cIjogaXRlbU51bSxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwic2l6ZVwiOiBcIjEyMioxMzVtbVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJzb2NrZXRcIjogXCJFMjZcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIFwicG93ZXJcIjogMTYsXG4gICAgICAgICAgICAgICAgICAgICAgICBcImJyaWdodG5lc3NcIjogMTI1MCxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwidGVtcGVyYXR1cmVcIjogMzAwMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiUmFcIjogXCI+PTgwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcInZvbHRhZ2VcIjogXCIxMDAtMTMwXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcImJlYW1fYW5nbGVcIjogMTIwLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJsaWZlX3RpbWVcIjogNTAwMDAsXG4gICAgICAgICAgICAgICAgICAgICAgICBcInBvd2VyX2ZhY3RvclwiOiBcIj49MC45XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcImRpbW1hYmxlXCI6IFwieWVzXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcImhvdXNpbmdcIjogXCJhbHVtaW51bVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJjb2xvdXJcIjogXCJzaWx2ZXJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiY292ZXJcIjogXCJnbGFzcyBsZW5zXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcImNlcnRpZmljYXRpb25cIjogW1wiQ0VcIiwgXCJFVExcIl0sXG4gICAgICAgICAgICAgICAgICAgICAgICBcImNhdGVnb3J5SWRcIjogaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBcInBpY3R1cmVcIjogXCJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIFwicHJpY2VcIjogMTAuOTksXG4gICAgICAgICAgICAgICAgICAgICAgICBcInF1YW50aXR5SW5TdG9ja1wiOiAxMDAsXG4gICAgICAgICAgICAgICAgICAgICAgICBcInF1YW50aXR5T25Ib2xkXCI6IDEwLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCJkaXNjb3VudF9wY3RcIjogMTAsXG4gICAgICAgICAgICAgICAgICAgICAgICBcInN0YXR1c1wiOiB0cnVlXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gUHJvZHVjdHMuaW5zZXJ0KFxuICAgICAgICAgICAgLy8gICAgIHtcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJpdGVtTnVtXCI6IFwiRFBBUjM4LTE2V1QoUzIpXCIsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwic2l6ZVwiOiBcIjEyMioxMzVtbVwiLFxuICAgICAgICAgICAgLy8gICAgICAgICBcInNvY2tldFwiOiBcIkUyNlwiLFxuICAgICAgICAgICAgLy8gICAgICAgICBcInBvd2VyXCI6IDE2LFxuICAgICAgICAgICAgLy8gICAgICAgICBcImJyaWdodG5lc3NcIjogMTI1MCxcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJ0ZW1wZXJhdHVyZVwiOiAzMDAwLFxuICAgICAgICAgICAgLy8gICAgICAgICBcIlJhXCI6IFwiPj04MFwiLFxuICAgICAgICAgICAgLy8gICAgICAgICBcInZvbHRhZ2VcIjogXCIxMDAtMTMwXCIsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwiYmVhbV9hbmdsZVwiOiAxMjAsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwibGlmZV90aW1lXCI6IDUwMDAwLFxuICAgICAgICAgICAgLy8gICAgICAgICBcInBvd2VyX2ZhY3RvclwiOiBcIj49MC45XCIsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwiZGltbWFibGVcIjogXCJ5ZXNcIixcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJob3VzaW5nXCI6IFwiYWx1bWludW1cIixcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJjb2xvdXJcIjogXCJzaWx2ZXJcIixcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJjb3ZlclwiOiBcImdsYXNzIGxlbnNcIixcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJjZXJ0aWZpY2F0aW9uXCI6IFtcIkNFXCIsIFwiRVRMXCJdLFxuICAgICAgICAgICAgLy8gICAgICAgICBcImNhdGVnb3J5SWRcIjogaWQsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwicGljdHVyZVwiOiBcIlwiLFxuICAgICAgICAgICAgLy8gICAgICAgICBcInByaWNlXCI6IDEwLjk5LFxuICAgICAgICAgICAgLy8gICAgICAgICBcInF1YW50aXR5SW5TdG9ja1wiOiAxMDAsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwicXVhbnRpdHlPbkhvbGRcIjogMTAsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwiZGlzY291bnRfcGN0XCI6IDAuMVxuICAgICAgICAgICAgLy8gICAgIH0sXG4gICAgICAgICAgICAvLyApO1xuICAgICAgICAgICAgLy8gUHJvZHVjdHMuaW5zZXJ0KFxuICAgICAgICAgICAgLy8gICAgIHtcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJpdGVtTnVtXCI6IFwiRFBBUjM4LTE2V1QoUzIpXCIsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwic2l6ZVwiOiBcIjEyMioxMzVtbVwiLFxuICAgICAgICAgICAgLy8gICAgICAgICBcInNvY2tldFwiOiBcIkUyN1wiLFxuICAgICAgICAgICAgLy8gICAgICAgICBcInBvd2VyXCI6IDE2LFxuICAgICAgICAgICAgLy8gICAgICAgICBcImJyaWdodG5lc3NcIjogMTI1MCxcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJ0ZW1wZXJhdHVyZVwiOiAzMDAwLFxuICAgICAgICAgICAgLy8gICAgICAgICBcIlJhXCI6IFwiPj04MFwiLFxuICAgICAgICAgICAgLy8gICAgICAgICBcInZvbHRhZ2VcIjogXCIxMDAtMTMwXCIsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwiYmVhbV9hbmdsZVwiOiAxMjAsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwibGlmZV90aW1lXCI6IDUwMDAwLFxuICAgICAgICAgICAgLy8gICAgICAgICBcInBvd2VyX2ZhY3RvclwiOiBcIj49MC45XCIsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwiZGltbWFibGVcIjogXCJ5ZXNcIixcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJob3VzaW5nXCI6IFwiYWx1bWludW1cIixcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJjb2xvdXJcIjogXCJzaWx2ZXJcIixcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJjb3ZlclwiOiBcImdsYXNzIGxlbnNcIixcbiAgICAgICAgICAgIC8vICAgICAgICAgXCJjZXJ0aWZpY2F0aW9uXCI6IFtcIkNFXCIsIFwiRVRMXCJdLFxuICAgICAgICAgICAgLy8gICAgICAgICBcImNhdGVnb3J5SWRcIjogaWQsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwicGljdHVyZVwiOiBcIlwiLFxuICAgICAgICAgICAgLy8gICAgICAgICBcInByaWNlXCI6IDEwLjk5LFxuICAgICAgICAgICAgLy8gICAgICAgICBcInF1YW50aXR5SW5TdG9ja1wiOiAxMDAsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwicXVhbnRpdHlPbkhvbGRcIjogMTAsXG4gICAgICAgICAgICAvLyAgICAgICAgIFwiZGlzY291bnRfcGN0XCI6IDBcbiAgICAgICAgICAgIC8vICAgICB9XG4gICAgICAgICAgICAvLyApO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKE1ldGVvci5yb2xlcy5maW5kT25lKHtuYW1lOiBcInN1cGVyLWFkbWluXCJ9KSA9PSB1bmRlZmluZWQpe1xuICAgICAgICAgICAgQWNjb3VudHMuY3JlYXRlVXNlcih7XG4gICAgICAgICAgICAgICAgZW1haWw6IFwic3VwZXIuYWRtaW5AbGVkLmNvbVwiLFxuICAgICAgICAgICAgICAgIHBhc3N3b3JkOiBcIjEyMzQ1Njc4XCIsXG4gICAgICAgICAgICAgICAgcHJvZmlsZToge1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiBcInN1cGVyLWFkbWluXCIsXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogXCJhY3RpdmVcIlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgLy8gICAgICAgIFJvbGVzLnNldFVzZXJSb2xlcyh0YXJnZXRVc2VySWQsIHJvbGVzLCBncm91cCk7XG5cbiAgICAgICAgICAgIFJvbGVzLnNldFVzZXJSb2xlcyhNZXRlb3IudXNlcnMuZmluZE9uZSh7XCJwcm9maWxlLm5hbWVcIjogXCJzdXBlci1hZG1pblwifSkuX2lkLCBbXCJzdXBlci1hZG1pblwiXSwgJ2xlZCcpO1xuICAgICAgICB9XG5cbiAgICB9KTtcblxuIl19
}).call(this);

//# sourceMappingURL=loadCategories.js.map
