(function(){Meteor.publish('images', function () {
    return Images.find({});
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9zZXJ2ZXIvaW1hZ2VzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLFlBQVc7QUFDaEMsV0FBTyxNQUFNLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0NBQzFCLENBQUMsQ0FBQyIsImZpbGUiOiIvc2VydmVyL2ltYWdlcy5qcyIsInNvdXJjZXNDb250ZW50IjpbIk1ldGVvci5wdWJsaXNoKCdpbWFnZXMnLCBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gSW1hZ2VzLmZpbmQoe30pO1xufSk7XG4iXX0=
}).call(this);

//# sourceMappingURL=images.js.map
